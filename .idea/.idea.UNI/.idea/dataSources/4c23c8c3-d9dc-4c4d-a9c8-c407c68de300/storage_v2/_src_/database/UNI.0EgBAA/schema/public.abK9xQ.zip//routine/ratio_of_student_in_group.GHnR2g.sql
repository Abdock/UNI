create function ratio_of_student_in_group(gid bigint, sid bigint, grade_begin double precision, grade_end double precision) returns double precision
    language sql
as
$$
select t1.cnt::double precision / t2.cnt::double precision from 
        (select count(*) as cnt from students_of_group_that_have_midterm_grade_in_range(gid, sid, grade_begin, grade_end)) as t1,
        (select count(*) as cnt from students_of_group(gid)) as t2;
$$;

alter function ratio_of_student_in_group(bigint, bigint, double precision, double precision) owner to postgres;

