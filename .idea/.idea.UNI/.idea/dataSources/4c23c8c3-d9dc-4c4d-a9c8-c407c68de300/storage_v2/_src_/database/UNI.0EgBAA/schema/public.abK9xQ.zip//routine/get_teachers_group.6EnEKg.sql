create function get_teachers_group(uid bigint) returns SETOF "group"
    language sql
as
$$
select g.* from "group" g 
            join teacher t on g.curator_id = t.teacher_id
            join users u on u.second_id = t.teacher_id and u.user_id = uid;
$$;

alter function get_teachers_group(bigint) owner to postgres;

