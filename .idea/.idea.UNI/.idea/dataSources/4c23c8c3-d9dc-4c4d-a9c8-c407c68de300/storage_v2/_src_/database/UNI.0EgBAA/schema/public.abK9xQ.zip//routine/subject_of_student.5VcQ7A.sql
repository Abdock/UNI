create function subject_of_student() returns trigger
    language plpgsql
as
$$
BEGIN
            insert into exam(student_id, subject_id) 
            select s.student_id, s2.subject_id from student s
            join "group" g on s.group_id = g.group_id and new.group_id = g.group_id
            join subject s2 on new.subject_id = s2.subject_id;
            return new;
        END;
$$;

alter function subject_of_student() owner to postgres;

