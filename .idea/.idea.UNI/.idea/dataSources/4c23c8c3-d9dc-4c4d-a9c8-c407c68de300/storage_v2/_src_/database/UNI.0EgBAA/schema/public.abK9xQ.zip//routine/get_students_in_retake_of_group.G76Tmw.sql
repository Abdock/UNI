create function get_students_in_retake_of_group(gid bigint, sid bigint) returns SETOF student
    language sql
as
$$
select s.* from student s 
            join "group" g on s.group_id = g.group_id and g.group_id = gid
            join schedule s2 on g.group_id = s2.group_id and s2.subject_id = sid
            join exam e on e.subject_id = s2.subject_id and e.student_id = s.student_id and e.final < 50;
$$;

alter function get_students_in_retake_of_group(bigint, bigint) owner to postgres;

