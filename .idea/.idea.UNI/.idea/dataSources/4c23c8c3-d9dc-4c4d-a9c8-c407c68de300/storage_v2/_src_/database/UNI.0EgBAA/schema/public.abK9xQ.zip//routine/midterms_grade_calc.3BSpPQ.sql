create function midterms_grade_calc() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (is_second_semester(new.student_id)) THEN
        IF (EXISTS(SELECT mr.group_id, mr.subject_id FROM student s
                  JOIN "group" g ON s.group_id = g.group_id AND new.student_id = s.student_id
                  JOIN endterm_result mr on g.group_id = mr.group_id AND mr.subject_id = new.subject_id)) THEN
            INSERT INTO endterm_result(group_id, subject_id, excellent, good, middle, low) 
            VALUES((select group_id from student where student.student_id = new.student_id), new.subject_id,
                ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 90, 100),
                ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 70, 89),
                ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 50, 69),
                ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 0, 50));
        ELSE
            UPDATE endterm_result
            SET
                excellent = ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 90, 100),
                good = ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 70, 89),
                middle = ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 50, 69),
                low = ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 0, 50)
            WHERE endterm_result.subject_id = new.subject_id
              AND endterm_result.group_id = (SELECT g.group_id FROM
                "group" g JOIN
                student s3 on g.group_id = s3.group_id AND s3.student_id = new.student_id);
        END IF;
    ELSE
        IF (EXISTS(SELECT mr.group_id, mr.subject_id FROM student s
                      JOIN "group" g ON s.group_id = g.group_id AND new.student_id = s.student_id
                      JOIN midterm_result mr on g.group_id = mr.group_id AND mr.subject_id = new.subject_id)) THEN
            INSERT INTO midterm_result(group_id, subject_id, excellent, good, middle, low)
            VALUES((select group_id from student where student.student_id = new.student_id), new.subject_id,
                   ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 90, 100),
                   ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 70, 89),
                   ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 50, 69),
                   ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 0, 50));
        ELSE
            UPDATE midterm_result
            SET
                excellent = ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 90, 100),
                good = ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 70, 89),
                middle = ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 50, 69),
                low = ratio_of_student_in_group((select g.group_id from "group" g join student s2 on g.group_id = s2.group_id and s2.student_id = new.student_id), new.subject_id, 0, 50)
            WHERE midterm_result.subject_id = new.subject_id
              AND midterm_result.group_id = (SELECT g.group_id FROM
                "group" g JOIN
                student s3 on g.group_id = s3.group_id AND s3.student_id = new.student_id);
        END IF;
    END IF;
    RETURN NEW;
end;
$$;

alter function midterms_grade_calc() owner to postgres;

