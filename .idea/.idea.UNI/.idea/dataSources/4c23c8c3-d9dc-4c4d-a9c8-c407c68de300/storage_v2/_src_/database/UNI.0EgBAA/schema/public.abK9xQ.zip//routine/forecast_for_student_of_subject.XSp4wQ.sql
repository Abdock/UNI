create function forecast_for_student_of_subject(us bigint, sub bigint) returns double precision
    language sql
as
$$
SELECT AVG(grade) * (1 - SUM(weight)) FROM attendance a JOIN users u
        ON u.user_id = us AND u.second_id = a.student_id AND a.subject_id = sub
$$;

alter function forecast_for_student_of_subject(bigint, bigint) owner to postgres;

