create function current_week(st bigint) returns integer
    language sql
as
$$
select (current_date - begin_date) / 7 from semesters_date
            join student s on semesters_date.semester_id = s.semester_id
                and s.student_id = st
$$;

alter function current_week(bigint) owner to postgres;

