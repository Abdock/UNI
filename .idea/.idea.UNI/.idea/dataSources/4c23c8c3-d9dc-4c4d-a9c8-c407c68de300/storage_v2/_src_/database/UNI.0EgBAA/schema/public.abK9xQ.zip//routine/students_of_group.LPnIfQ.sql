create function students_of_group(gid bigint) returns SETOF student
    language sql
as
$$
select s.* from "group" g
            join student s on g.group_id = s.group_id and g.group_id = gid;
$$;

alter function students_of_group(bigint) owner to postgres;

