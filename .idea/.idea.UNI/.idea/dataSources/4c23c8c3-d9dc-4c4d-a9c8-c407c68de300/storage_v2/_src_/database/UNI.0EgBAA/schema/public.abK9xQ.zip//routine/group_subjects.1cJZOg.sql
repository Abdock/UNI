create function group_subjects(gid bigint) returns SETOF subject
    language sql
as
$$
select s2.* from "group" g 
            join schedule s on g.group_id = s.group_id and g.group_id = gid
            join subject s2 on s.subject_id = s2.subject_id
$$;

alter function group_subjects(bigint) owner to postgres;

