create function check_level() returns trigger
    language plpgsql
as
$$
begin
            if (old.grade is not null and new.grade > old.grade and new.grade >= 80) then
                update student set english_skill = english_skill + 1 where student.student_id = new.student_id;
            else 
                if (old.grade is null and new.grade >= 80) then
                    update student set english_skill = english_skill + 1 where student.student_id = new.student_id;
                end if;
            end if;
            return new;
        end;
$$;

alter function check_level() owner to postgres;

