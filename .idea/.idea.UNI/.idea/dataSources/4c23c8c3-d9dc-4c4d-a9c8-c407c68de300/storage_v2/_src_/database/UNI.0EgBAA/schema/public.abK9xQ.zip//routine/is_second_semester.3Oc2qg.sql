create function is_second_semester(st bigint) returns boolean
    language sql
as
$$
select (current_date - begin_date) / 7 <= (end_date - begin_date) / 7 / 2 from semesters_date
            join student s on semesters_date.semester_id = s.semester_id
                and s.student_id = 5
$$;

alter function is_second_semester(bigint) owner to postgres;

