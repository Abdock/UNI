create function students_of_group_that_have_midterm_grade_in_range(g_id bigint, sid bigint, grade_begin double precision, grade_end double precision) returns SETOF student
    language sql
as
$$
select s.* from "group" g
            join student s on g.group_id = s.group_id and g.group_id = g_id
            join schedule s2 on g.group_id = s2.group_id
            join subject s3 on s2.subject_id = s3.subject_id and s3.subject_id = sid
            join exam e on s.student_id = e.student_id and e.subject_id = s3.subject_id
                and e.midterm between grade_begin and grade_end;
$$;

alter function students_of_group_that_have_midterm_grade_in_range(bigint, bigint, double precision, double precision) owner to postgres;

