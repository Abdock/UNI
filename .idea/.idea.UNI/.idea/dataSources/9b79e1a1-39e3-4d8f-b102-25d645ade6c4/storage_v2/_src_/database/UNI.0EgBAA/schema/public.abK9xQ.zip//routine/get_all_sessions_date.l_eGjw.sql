create function get_all_sessions_date(us bigint)
    returns TABLE(subject_id bigint, subject_name character varying, session_date date, credits integer)
    language sql
as
$$
SELECT s1.subject_id, s1.subject_name, a.session_date, s1.credits FROM subject s1
            JOIN attendance a on s1.subject_id = a.subject_id
            JOIN student s on a.student_id = s.student_id
            JOIN users u on u.second_id = s.student_id AND u.user_id = us
        WHERE a.session_date > current_date
$$;

alter function get_all_sessions_date(bigint) owner to postgres;

