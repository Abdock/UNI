create function get_current_attendance(us bigint, sub bigint) returns double precision
    language sql
as
$$
SELECT ( COUNT(*)::double precision / 14.0) FROM users u 
            JOIN student s ON u.second_id = s.student_id AND u.user_id = us
            JOIN attendance a on s.student_id = a.student_id AND a.subject_id = sub
$$;

alter function get_current_attendance(bigint, bigint) owner to postgres;

