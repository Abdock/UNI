create function student_grades_of_subject(users_id bigint, lesson_id bigint) returns SETOF attendance
    language sql
as
$$
SELECT a.* FROM attendance a JOIN
            student s on a.student_id = s.student_id AND a.subject_id = lesson_id JOIN
            users u on u.second_id = s.student_id AND u.user_id = users_id
$$;

alter function student_grades_of_subject(bigint, bigint) owner to postgres;

