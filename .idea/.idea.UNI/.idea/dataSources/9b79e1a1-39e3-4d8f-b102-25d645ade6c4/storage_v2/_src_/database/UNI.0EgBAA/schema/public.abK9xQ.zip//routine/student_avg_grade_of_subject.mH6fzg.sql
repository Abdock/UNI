create function student_avg_grade_of_subject(users_id bigint, lesson_id bigint) returns double precision
    language sql
as
$$
SELECT AVG(grade) FROM attendance a JOIN
            student s on a.student_id = s.student_id AND a.subject_id = lesson_id JOIN
            users u on u.second_id = s.student_id AND u.user_id = users_id
$$;

alter function student_avg_grade_of_subject(bigint, bigint) owner to postgres;

