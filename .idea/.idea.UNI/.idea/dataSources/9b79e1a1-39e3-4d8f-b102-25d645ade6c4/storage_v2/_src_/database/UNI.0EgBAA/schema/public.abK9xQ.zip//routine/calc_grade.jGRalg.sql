create function calc_grade() returns trigger
    language plpgsql
as
$$
BEGIN
            IF new.grade > 100 THEN
                new.grade = 100;
            end if;
            IF new.grade < 0 THEN
                new.grade = 0;
            end if;
            if new.weight > 1 then
                new.weight = 1; 
            end if;
            if new.weight < 0 then
                new.weight = 0;
            end if;
            if exists(select * from exam where student_id = new.student_id and subject_id = new.subject_id) then
                if new.week > 7 then
                    update exam set endterm = endterm + (new.grade * new.weight) where exam.student_id = new.student_id and exam.subject_id = new.subject_id;
                else
                    update exam set midterm = midterm + (new.grade * new.weight) where exam.student_id = new.student_id and exam.subject_id = new.subject_id;
                end if;
            else
                insert into exam(student_id, subject_id) values(new.student_id, new.subject_id);
                if new.week > 7 then
                    update exam set endterm = endterm + (new.grade * new.weight) where exam.student_id = new.student_id and exam.subject_id = new.subject_id;
                else
                    update exam set midterm = midterm + (new.grade * new.weight) where exam.student_id = new.student_id and exam.subject_id = new.subject_id;
                end if;
            end if;
            update exam set final = midterm * 0.3 + endterm * 0.3 + session * 0.4 where exam.student_id = new.student_id and exam.subject_id = new.subject_id;
            return new;
        END;
$$;

alter function calc_grade() owner to postgres;

