create function student_subjects(users_id bigint) returns SETOF subject
    language sql
as
$$
SELECT s3.* FROM users u
            JOIN student s ON u.second_id = s.student_id AND u.user_id = users_id
            JOIN "group" g on s.group_id = g.group_id
            JOIN schedule s2 on g.group_id = s2.group_id
            JOIN subject s3 on s2.subject_id = s3.subject_id
$$;

alter function student_subjects(bigint) owner to postgres;

